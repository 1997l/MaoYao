# Loading

Loading 使用开源项目：[claudiocalautti/spring-loaders](https://github.com/claudiocalautti/spring-loaders)

大家可以根据该项目文档修改```window.cnblogsConfig.loading```的配置。